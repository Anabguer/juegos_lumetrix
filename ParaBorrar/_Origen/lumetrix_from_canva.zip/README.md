# Lumetrix (export desde tu Canva)

Este zip contiene el juego tal como lo tienes en el Canva (diseño y funcionalidades).
Arranque rápido:

```bash
npm install
npm run dev
```

Abre el enlace que te muestra Vite (normalmente `http://localhost:5173`).

Build de producción:
```bash
npm run build
npm run preview
```
